<img src="{{asset('frontend/images/logo.png')}}" height="85" width="200" />
